#!/usr/bin/env python3
"""Static project sanity check. NOT an Android compiler or runtime test."""
from pathlib import Path
import xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
for rel in [
    'app/build.gradle.kts', 'build.gradle.kts', 'settings.gradle.kts',
    'app/src/main/AndroidManifest.xml',
    'app/src/main/java/com/polylingo/ai/MainActivity.kt',
    'app/src/main/java/com/polylingo/ai/core/TranslationEngine.kt',
    '.github/workflows/android.yml',
]:
    assert (root / rel).is_file(), f'Missing {rel}'
for path in (root / 'app/src/main/res').rglob('*.xml'):
    ET.parse(path)
ET.parse(root / 'app/src/main/AndroidManifest.xml')
lang = (root / 'app/src/main/java/com/polylingo/ai/core/PolyLanguage.kt').read_text()
for code in ['BN("bn"', 'EN("en"', 'AR("ar"', 'HI("hi"', 'UR("ur"']:
    assert code in lang, f'Missing language {code}'
print('PASS: source layout, 5 languages, XML parsing. Full Android build NOT verified.')
