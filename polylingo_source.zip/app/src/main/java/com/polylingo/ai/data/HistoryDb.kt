package com.polylingo.ai.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.polylingo.ai.core.PolyLanguage

data class HistoryItem(
    val id: Long,
    val source: PolyLanguage,
    val target: PolyLanguage,
    val original: String,
    val translated: String,
    val favorite: Boolean
)

class HistoryDb(context: Context) : SQLiteOpenHelper(context, "polylingo_history.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE translations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                target TEXT NOT NULL,
                original TEXT NOT NULL,
                translated TEXT NOT NULL,
                favorite INTEGER NOT NULL DEFAULT 0,
                created_at INTEGER NOT NULL
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun add(source: PolyLanguage, target: PolyLanguage, original: String, translated: String): Long {
        val values = ContentValues().apply {
            put("source", source.code)
            put("target", target.code)
            put("original", original)
            put("translated", translated)
            put("favorite", 0)
            put("created_at", System.currentTimeMillis())
        }
        return writableDatabase.insertOrThrow("translations", null, values)
    }

    fun setFavorite(id: Long, favorite: Boolean) {
        val values = ContentValues().apply { put("favorite", if (favorite) 1 else 0) }
        writableDatabase.update("translations", values, "id=?", arrayOf(id.toString()))
    }

    fun list(favoritesOnly: Boolean = false, limit: Int = 30): List<HistoryItem> {
        val result = mutableListOf<HistoryItem>()
        val selection = if (favoritesOnly) "favorite=1" else null
        readableDatabase.query(
            "translations", arrayOf("id", "source", "target", "original", "translated", "favorite"),
            selection, null, null, null, "id DESC", limit.toString()
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val source = PolyLanguage.fromCode(cursor.getString(1)) ?: continue
                val target = PolyLanguage.fromCode(cursor.getString(2)) ?: continue
                result.add(HistoryItem(cursor.getLong(0), source, target, cursor.getString(3), cursor.getString(4), cursor.getInt(5) == 1))
            }
        }
        return result
    }

    fun clearNonFavorites() { writableDatabase.delete("translations", "favorite=0", null) }
}
