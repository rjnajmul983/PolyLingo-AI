package com.polylingo.ai.core

/** Intentionally small, transparent, fully local correction rules.
 * Not a substitute for a full grammar model or a comprehensive dictionary.
 */
object Corrections {
    data class Outcome(val text: String, val changes: Int)

    fun correct(text: String, language: PolyLanguage): Outcome {
        var result = text.trim().replace(Regex("[\\t ]{2,}"), " ")
        var changes = if (result != text) 1 else 0

        val rules: List<Pair<Regex, String>> = when (language) {
            PolyLanguage.EN -> listOf(
                Regex("\\bteh\\b", RegexOption.IGNORE_CASE) to "the",
                Regex("\\brecieve\\b", RegexOption.IGNORE_CASE) to "receive",
                Regex("\\bdefinately\\b", RegexOption.IGNORE_CASE) to "definitely",
                Regex("\\bseperate\\b", RegexOption.IGNORE_CASE) to "separate",
                Regex("\\boccured\\b", RegexOption.IGNORE_CASE) to "occurred",
                Regex("\\bdont\\b", RegexOption.IGNORE_CASE) to "don't",
                Regex("\\bcant\\b", RegexOption.IGNORE_CASE) to "can't",
                Regex("\\bI is\\b") to "I am",
                Regex("\\bI has\\b") to "I have",
                Regex("\\bHe go\\b") to "He goes",
                Regex("\\bShe go\\b") to "She goes",
                Regex("\\ba apple\\b", RegexOption.IGNORE_CASE) to "an apple",
                Regex("\\bthe[ ]+the\\b", RegexOption.IGNORE_CASE) to "the"
            )
            PolyLanguage.AR -> listOf(
                Regex("انشاء الله") to "إن شاء الله",
                Regex("هاذا") to "هذا",
                Regex("هاذه") to "هذه",
                Regex("اللغه") to "اللغة"
            )
            PolyLanguage.BN -> listOf(
                Regex("যাইতেছি") to "যাচ্ছি",
                Regex("করতেছি") to "করছি",
                Regex("হইছে") to "হয়েছে"
            )
            PolyLanguage.HI -> listOf(
                Regex("(?<![\\p{L}])मै(?![\\p{L}])") to "मैं",
                Regex("हू(?![\\p{L}])") to "हूँ"
            )
            PolyLanguage.UR -> listOf(
                Regex("اپ") to "آپ",
                Regex("ھیں") to "ہیں"
            )
        }
        for ((pattern, replacement) in rules) {
            val changed = pattern.replace(result, replacement)
            if (changed != result) {
                changes++
                result = changed
            }
        }
        return Outcome(result, changes)
    }
}
