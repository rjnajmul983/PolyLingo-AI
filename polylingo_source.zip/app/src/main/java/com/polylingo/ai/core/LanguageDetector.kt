package com.polylingo.ai.core

import com.google.mlkit.nl.languageid.LanguageIdentification

class LanguageDetector {
    private val client = LanguageIdentification.getClient()

    fun detect(text: String, callback: (PolyLanguage?) -> Unit) {
        val scriptHint = scriptGuess(text)
        if (scriptHint != null && scriptHint != PolyLanguage.AR) {
            callback(scriptHint)
            return
        }
        client.identifyLanguage(text)
            .addOnSuccessListener { tag -> callback(PolyLanguage.fromCode(tag) ?: scriptHint) }
            .addOnFailureListener { callback(scriptHint) }
    }

    fun close() = client.close()

    companion object {
        fun scriptGuess(text: String): PolyLanguage? {
            if (text.any { it in '\u0980'..'\u09FF' }) return PolyLanguage.BN
            if (text.any { it in '\u0900'..'\u097F' }) return PolyLanguage.HI
            if (text.any { it in "ٹڈڑںھہےگپچژک" }) return PolyLanguage.UR
            if (text.any { it in '\u0600'..'\u06FF' }) return PolyLanguage.AR
            if (text.any { it in 'A'..'Z' || it in 'a'..'z' }) return PolyLanguage.EN
            return null
        }
    }
}
