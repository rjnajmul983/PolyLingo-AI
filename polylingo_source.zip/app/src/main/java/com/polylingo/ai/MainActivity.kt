package com.polylingo.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import com.polylingo.ai.core.Corrections
import com.polylingo.ai.core.LanguageDetector
import com.polylingo.ai.core.OfflineModels
import com.polylingo.ai.core.PolyLanguage
import com.polylingo.ai.core.TranslationEngine
import com.polylingo.ai.data.HistoryDb
import com.polylingo.ai.data.HistoryItem
import com.polylingo.ai.speech.OfflineSpeaker
import com.polylingo.ai.speech.OfflineVoice

class MainActivity : Activity() {
    private data class Palette(
        val background: Int, val surface: Int, val border: Int,
        val text: Int, val muted: Int, val accent: Int, val softAccent: Int,
        val onAccent: Int
    )

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var history: HistoryDb
    private lateinit var detector: LanguageDetector
    private lateinit var engine: TranslationEngine
    private lateinit var models: OfflineModels
    private lateinit var speaker: OfflineSpeaker
    private lateinit var voice: OfflineVoice
    private lateinit var colors: Palette
    private lateinit var scroll: ScrollView
    private lateinit var sourceSpinner: Spinner
    private lateinit var targetSpinner: Spinner
    private lateinit var inputField: EditText
    private lateinit var outputText: TextView
    private lateinit var statusText: TextView
    private lateinit var modelStatus: TextView
    private lateinit var downloadButton: TextView
    private lateinit var speakButton: TextView
    private lateinit var favoriteButton: TextView
    private lateinit var historyList: LinearLayout
    private lateinit var favoritesToggle: TextView
    private lateinit var translateButton: TextView

    private var dark = false
    private var uiBn = true
    private var sourceIndex = 0 // Auto + 5 languages
    private var targetIndex = 1 // English
    private var lastInput = ""
    private var lastOutput = ""
    private var currentRecordId: Long? = null
    private var currentFavorite = false
    private var lastDetected: PolyLanguage? = null
    private var modelsReady = false
    private var downloading = false
    private var translating = false
    private var favoritesOnly = false
    private var pendingMicLanguage: PolyLanguage? = null
    private val micPermissionRequest = 2201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("polylingo_prefs", MODE_PRIVATE)
        dark = prefs.getBoolean("dark", false)
        uiBn = prefs.getBoolean("ui_bn", true)
        history = HistoryDb(this)
        detector = LanguageDetector()
        engine = TranslationEngine()
        models = OfflineModels()
        speaker = OfflineSpeaker(this)
        voice = OfflineVoice(this)
        render()
        readSharedText(intent)
        refreshModels()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        readSharedText(intent)
    }

    private fun readSharedText(intent: Intent?) {
        val incoming = when (intent?.action) {
            Intent.ACTION_PROCESS_TEXT -> intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
            Intent.ACTION_SEND -> if (intent.type == "text/plain") intent.getStringExtra(Intent.EXTRA_TEXT) else null
            else -> null
        }
        if (!incoming.isNullOrBlank()) {
            lastInput = incoming
            lastOutput = ""
            currentRecordId = null
            currentFavorite = false
            inputField.setText(incoming)
            outputText.text = ""
            status(tr("Text received. Tap Translate.", "লেখা পাওয়া গেছে। অনুবাদ চাপুন।"))
            scroll.smoothScrollTo(0, 0)
        }
    }

    private fun tr(en: String, bn: String): String = if (uiBn) bn else en
    private fun dp(n: Int) = (n * resources.displayMetrics.density + 0.5f).toInt()
    private fun parse(hex: String): Int = Color.parseColor(hex)

    private fun themePalette() = if (dark) Palette(
        parse("#0A1020"), parse("#151E32"), parse("#2B3651"),
        parse("#F2F5FF"), parse("#A3B0CD"), parse("#8C7CF7"), parse("#2D2759"), Color.WHITE
    ) else Palette(
        parse("#F3F6FC"), Color.WHITE, parse("#DFE5F1"),
        parse("#152039"), parse("#66748F"), parse("#6657E8"), parse("#EEECFF"), Color.WHITE
    )

    private fun rounded(fill: Int, radius: Int = 18, stroke: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            if (stroke != null) setStroke(dp(1), stroke)
        }

    private fun text(
        value: String, size: Float = 15f, bold: Boolean = false, muted: Boolean = false
    ): TextView = TextView(this).apply {
        this.text = value
        setTextColor(if (muted) colors.muted else colors.text)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setLineSpacing(dp(2).toFloat(), 1f)
    }

    private fun button(
        value: String, primary: Boolean = false, small: Boolean = false, action: () -> Unit
    ): TextView = text(value, if (small) 13f else 14f, true).apply {
        gravity = Gravity.CENTER
        setTextColor(if (primary) colors.onAccent else colors.text)
        background = rounded(if (primary) colors.accent else colors.softAccent, if (small) 12 else 14)
        setPadding(dp(if (small) 11 else 16), dp(if (small) 10 else 13), dp(if (small) 11 else 16), dp(if (small) 10 else 13))
        isClickable = true
        isFocusable = true
        contentDescription = value
        setOnClickListener { action() }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(17), dp(18), dp(17), dp(18))
        background = rounded(colors.surface, 22, colors.border)
    }

    private fun row(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun gap(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun hGap(width: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(dp(width), 1)
    }

    private fun fullCard(root: LinearLayout, c: LinearLayout) {
        root.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(15)
        })
    }

    private fun createSpinner(items: List<String>, selected: Int, changed: (Int) -> Unit): Spinner {
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, items) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View =
                decorate(super.getView(position, convertView, parent), false)
            override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View =
                decorate(super.getDropDownView(position, convertView, parent), true)
            private fun decorate(view: View, dropdown: Boolean): View = view.apply {
                (this as? TextView)?.apply {
                    setTextColor(colors.text)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                    setPadding(dp(10), dp(13), dp(10), dp(13))
                }
                if (dropdown) setBackgroundColor(colors.surface)
            }
        }
        return Spinner(this).apply {
            this.adapter = adapter
            background = rounded(colors.softAccent, 13)
            setSelection(selected)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: AdapterView<*>?) = Unit
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                    changed(position)
                }
            }
        }
    }

    private fun render() {
        colors = themePalette()
        window.statusBarColor = colors.background
        window.navigationBarColor = colors.background
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (dark) 0 else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(colors.background)
        }
        val main = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(17), dp(25), dp(17), dp(36))
        }
        scroll.addView(main)
        setContentView(scroll)

        val header = row()
        val mark = text("✦", 25f, true).apply {
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = rounded(colors.accent, 16)
        }
        header.addView(mark, LinearLayout.LayoutParams(dp(52), dp(52)))
        header.addView(hGap(12))
        val headerCopy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        headerCopy.addView(text("PolyLingo AI", 23f, true))
        headerCopy.addView(text(tr("Five languages. One private translator.", "পাঁচ ভাষা, এক অফলাইন অনুবাদক।"), 12f, muted = true))
        header.addView(headerCopy, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val themeButton = button(if (dark) "☀" else "☾", small = true) {
            dark = !dark
            prefs.edit().putBoolean("dark", dark).apply()
            render()
            refreshModels()
        }
        header.addView(themeButton)
        header.addView(hGap(7))
        header.addView(button(if (uiBn) "EN" else "বাং", small = true) {
            uiBn = !uiBn
            prefs.edit().putBoolean("ui_bn", uiBn).apply()
            render()
            refreshModels()
        })
        main.addView(header)
        main.addView(gap(20))

        val info = text(tr("● ON-DEVICE TRANSLATION · DOWNLOAD MODELS ONCE", "● ফোনেই অনুবাদ · প্রথমবার মডেল নামাতে হবে"), 11f, true).apply {
            setTextColor(colors.accent)
        }
        main.addView(info)
        main.addView(gap(12))

        val languageCard = card()
        languageCard.addView(text(tr("CHOOSE LANGUAGES", "ভাষা নির্বাচন করুন"), 12f, true, true))
        languageCard.addView(gap(10))
        val languageRow = row()
        val srcNames = listOf(tr("Auto detect", "স্বয়ংক্রিয়")) + PolyLanguage.entries.map { it.nativeName }
        sourceSpinner = createSpinner(srcNames, sourceIndex) { sourceIndex = it }
        targetSpinner = createSpinner(PolyLanguage.entries.map { it.nativeName }, targetIndex) {
            targetIndex = it
            if (::speakButton.isInitialized) updateSpeakButton()
        }
        languageRow.addView(sourceSpinner, LinearLayout.LayoutParams(0, dp(52), 1f))
        languageRow.addView(hGap(6))
        languageRow.addView(button("⇄", small = true) { swapLanguages() })
        languageRow.addView(hGap(6))
        languageRow.addView(targetSpinner, LinearLayout.LayoutParams(0, dp(52), 1f))
        languageCard.addView(languageRow)
        fullCard(main, languageCard)

        val inputCard = card()
        val inputHeader = row()
        inputHeader.addView(text(tr("SOURCE TEXT", "মূল লেখা"), 12f, true, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        inputHeader.addView(button(tr("Paste", "পেস্ট"), small = true) { pasteClipboard() })
        inputHeader.addView(hGap(8))
        inputHeader.addView(button(tr("🎙 Speak", "🎙 বলুন"), small = true) { requestMic() })
        inputCard.addView(inputHeader)
        inputCard.addView(gap(12))
        inputField = EditText(this).apply {
            setText(lastInput)
            hint = tr("Type or paste text here…", "এখানে লিখুন বা পেস্ট করুন…")
            setHintTextColor(colors.muted)
            setTextColor(colors.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            gravity = Gravity.TOP or Gravity.START
            minLines = 4
            maxLines = 10
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(colors.background, 14)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { lastInput = s?.toString() ?: "" }
                override fun afterTextChanged(s: Editable?) = Unit
            })
        }
        inputCard.addView(inputField, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        inputCard.addView(gap(12))
        val inputActions = row()
        inputActions.addView(button(tr("✓ Fix spelling", "✓ বানান সংশোধন"), small = true) { correctText() })
        inputActions.addView(hGap(9))
        translateButton = button(tr("Translate →", "অনুবাদ করুন →"), primary = true) { translate() }
        inputActions.addView(translateButton, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        inputCard.addView(inputActions)
        inputCard.addView(gap(9))
        inputCard.addView(button(tr("🔊 Hear original (English / Arabic)", "🔊 মূল লেখা শুনুন (ইংরেজি / আরবি)"), small = true) {
            speakOriginal()
        })
        fullCard(main, inputCard)

        val outputCard = card()
        val outputHeader = row()
        outputHeader.addView(text(tr("TRANSLATION", "অনুবাদ"), 12f, true, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        outputHeader.addView(text("✦ PolyLingo", 11f, true).apply { setTextColor(colors.accent) })
        outputCard.addView(outputHeader)
        outputCard.addView(gap(12))
        outputText = text(if (lastOutput.isEmpty()) tr("Your translation will appear here.", "এখানে অনুবাদ দেখা যাবে।") else lastOutput, 19f).apply {
            setTextColor(if (lastOutput.isEmpty()) colors.muted else colors.text)
            minHeight = dp(85)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(colors.background, 14)
        }
        outputCard.addView(outputText)
        outputCard.addView(gap(12))
        val outputActions = row()
        speakButton = button(tr("▶ Listen", "▶ শুনুন"), small = true) { speakTranslation() }
        outputActions.addView(speakButton)
        outputActions.addView(hGap(7))
        outputActions.addView(button(tr("Copy", "কপি"), small = true) { copyTranslation() })
        outputActions.addView(hGap(7))
        outputActions.addView(button(tr("Share", "শেয়ার"), small = true) { shareTranslation() })
        outputActions.addView(hGap(7))
        favoriteButton = button(if (currentFavorite) "★" else "☆", small = true) { toggleFavorite() }
        outputActions.addView(favoriteButton)
        outputCard.addView(outputActions)
        outputCard.addView(gap(9))
        val speedRow = row()
        speedRow.addView(text(tr("Voice speed", "ভয়েসের গতি"), 12f, muted = true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        speedRow.addView(button("0.8×", small = true) { speaker.setSpeed(0.8f); status(tr("Speech speed: slow", "ভয়েসের গতি: ধীর")) })
        speedRow.addView(hGap(6))
        speedRow.addView(button("1×", small = true) { speaker.setSpeed(1.0f); status(tr("Speech speed: normal", "ভয়েসের গতি: স্বাভাবিক")) })
        speedRow.addView(hGap(6))
        speedRow.addView(button("1.2×", small = true) { speaker.setSpeed(1.2f); status(tr("Speech speed: fast", "ভয়েসের গতি: দ্রুত")) })
        outputCard.addView(speedRow)
        updateSpeakButton()
        outputCard.addView(gap(13))
        statusText = text(tr("Ready to translate.", "অনুবাদের জন্য প্রস্তুত।"), 12f, muted = true)
        outputCard.addView(statusText)
        fullCard(main, outputCard)

        val packCard = card()
        packCard.addView(text(tr("OFFLINE LANGUAGE PACKS", "অফলাইন ভাষা মডেল"), 12f, true, true))
        packCard.addView(gap(7))
        packCard.addView(text(tr(
            "Download all five models once over Wi-Fi. After setup, translations run on your phone.",
            "প্রথমবার Wi-Fi দিয়ে পাঁচটি মডেল নামান। এরপর ফোনেই অনুবাদ হবে।"
        ), 13f, muted = true))
        packCard.addView(gap(9))
        modelStatus = text(tr("Checking installed packs…", "ইনস্টল করা মডেল যাচাই হচ্ছে…"), 13f)
        packCard.addView(modelStatus)
        packCard.addView(gap(10))
        val packActions = row()
        downloadButton = button(tr("↓ Download all", "↓ সব মডেল নামান"), primary = true, small = true) { downloadPacks() }
        packActions.addView(downloadButton)
        packActions.addView(hGap(9))
        packActions.addView(button(tr("↻ Check", "↻ যাচাই"), small = true) { refreshModels() })
        packCard.addView(packActions)
        fullCard(main, packCard)

        val historyCard = card()
        val historyHeader = row()
        historyHeader.addView(text(tr("HISTORY & FAVORITES", "ইতিহাস ও পছন্দের অনুবাদ"), 12f, true, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        favoritesToggle = button(if (favoritesOnly) tr("All", "সব") else tr("★ Saved", "★ সেভ"), small = true) {
            favoritesOnly = !favoritesOnly
            favoritesToggle.text = if (favoritesOnly) tr("All", "সব") else tr("★ Saved", "★ সেভ")
            renderHistory()
        }
        historyHeader.addView(favoritesToggle)
        historyCard.addView(historyHeader)
        historyCard.addView(gap(11))
        historyList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        historyCard.addView(historyList)
        historyCard.addView(gap(8))
        historyCard.addView(button(tr("Clear non-favorites", "পছন্দ ছাড়া ইতিহাস মুছুন"), small = true) {
            AlertDialog.Builder(this)
                .setTitle(tr("Clear history?", "ইতিহাস মুছবেন?"))
                .setMessage(tr("Saved favorites will remain.", "পছন্দের অনুবাদগুলো থাকবে।"))
                .setNegativeButton(tr("Cancel", "বাতিল"), null)
                .setPositiveButton(tr("Clear", "মুছুন")) { _, _ -> history.clearNonFavorites(); renderHistory() }
                .show()
        })
        fullCard(main, historyCard)
        main.addView(text(tr(
            "Translation powered by Google ML Kit. Privacy: no analytics; on-device processing after model setup.",
            "Google ML Kit দিয়ে অনুবাদ। গোপনীয়তা: অ্যানালিটিক্স নেই; মডেল সেটআপের পর ফোনেই অনুবাদ।"
        ), 12f, muted = true))
        renderHistory()
    }

    private fun updateSpeakButton() {
        if (!::speakButton.isInitialized) return
        speakButton.visibility = if (PolyLanguage.entries[targetIndex].supportsSpeech) View.VISIBLE else View.GONE
    }

    private fun status(message: String) {
        if (::statusText.isInitialized) statusText.text = message
    }

    private fun refreshModels() {
        models.installed { installed ->
            modelsReady = PolyLanguage.entries.all { it.code in installed }
            val names = PolyLanguage.entries.filter { it.code in installed }.joinToString(", ") { it.nativeName }
            modelStatus.text = if (modelsReady) tr(
                "✓ All 5 language packs are installed. Offline ready.",
                "✓ পাঁচটি মডেল ইনস্টল আছে। অফলাইনে প্রস্তুত।"
            ) else tr(
                "Installed ${installed.size}/5: ${names.ifBlank { "none" }}. Download the missing packs.",
                "ইনস্টল ${installed.size}/৫: ${names.ifBlank { "কোনোটিই নয়" }}। বাকি মডেল নামান।"
            )
            downloadButton.isEnabled = !downloading
            downloadButton.alpha = if (downloading) 0.5f else 1f
        }
    }

    private fun downloadPacks() {
        if (downloading) return
        downloading = true
        downloadButton.isEnabled = false
        downloadButton.alpha = 0.5f
        modelStatus.text = tr("Starting model downloads…", "মডেল ডাউনলোড শুরু হচ্ছে…")
        val errors = mutableListOf<String>()
        models.downloadAll(progress = { done, total, lang, error ->
            if (error != null) errors.add("${lang.englishName}: $error")
            modelStatus.text = tr("Completed $done/$total: ${lang.nativeName}", "সম্পন্ন $done/$total: ${lang.nativeName}")
        }, finished = {
            downloading = false
            refreshModels()
            if (errors.isNotEmpty()) status(tr("Some downloads failed. Check internet and retry.", "কিছু মডেল নামেনি। ইন্টারনেট দেখে আবার চেষ্টা করুন।"))
            else status(tr("Offline model setup completed.", "অফলাইন মডেল সেটআপ সম্পন্ন।"))
        })
    }

    private fun translate() {
        val original = inputField.text.toString().trim()
        if (original.isBlank()) { status(tr("Enter text first.", "আগে লেখা দিন।")); return }
        if (original.length > 4000) { status(tr("Use 4,000 characters or fewer per translation.", "একবারে সর্বোচ্চ ৪,০০০ অক্ষর দিন।")); return }
        if (translating) return
        if (!modelsReady) {
            status(tr("Download all five offline packs first.", "প্রথমে পাঁচটি অফলাইন মডেল ডাউনলোড করুন।"))
            return
        }
        translating = true
        translateButton.isEnabled = false
        translateButton.alpha = 0.6f
        status(tr("Translating on device…", "ফোনে অনুবাদ হচ্ছে…"))
        val target = PolyLanguage.entries[targetIndex]
        val selected = if (sourceIndex == 0) null else PolyLanguage.entries[sourceIndex - 1]
        if (selected == null) {
            detector.detect(original) { detected ->
                if (detected == null) {
                    finishTranslate(tr("Could not detect language. Select source manually.", "ভাষা বোঝা যায়নি। নিজে নির্বাচন করুন।"))
                } else {
                    lastDetected = detected
                    runTranslation(original, detected, target)
                }
            }
        } else {
            lastDetected = selected
            runTranslation(original, selected, target)
        }
    }

    private fun runTranslation(original: String, source: PolyLanguage, target: PolyLanguage) {
        engine.translate(original, source, target) { result ->
            result.fold(onSuccess = { translated ->
                lastOutput = translated
                outputText.text = translated
                outputText.setTextColor(colors.text)
                currentRecordId = history.add(source, target, original, translated)
                currentFavorite = false
                favoriteButton.text = "☆"
                renderHistory()
                finishTranslate(tr("✓ Translated: ${source.nativeName} → ${target.nativeName}", "✓ অনুবাদ হয়েছে: ${source.nativeName} → ${target.nativeName}"))
            }, onFailure = { error ->
                finishTranslate(tr("Translation failed: ${error.localizedMessage}. Check model packs.", "অনুবাদ হয়নি: ${error.localizedMessage}। মডেল যাচাই করুন।"))
            })
        }
    }

    private fun finishTranslate(message: String) {
        translating = false
        translateButton.isEnabled = true
        translateButton.alpha = 1f
        status(message)
    }

    private fun correctText() {
        val original = inputField.text.toString()
        if (original.isBlank()) return
        val selected = if (sourceIndex == 0) null else PolyLanguage.entries[sourceIndex - 1]
        if (selected == null) {
            detector.detect(original) { lang ->
                if (lang != null) applyCorrections(original, lang)
                else status(tr("Select a source language first.", "প্রথমে ভাষা নির্বাচন করুন।"))
            }
        } else applyCorrections(original, selected)
    }

    private fun applyCorrections(original: String, lang: PolyLanguage) {
        val result = Corrections.correct(original, lang)
        if (result.changes > 0) {
            inputField.setText(result.text)
            inputField.setSelection(result.text.length)
            status(tr("Applied ${result.changes} basic offline correction(s). Not a full grammar checker.", "${result.changes}টি সাধারণ সংশোধন হয়েছে। এটি পূর্ণাঙ্গ গ্রামার চেকার নয়।"))
        } else status(tr("No matches in the built-in basic correction rules.", "বেসিক সংশোধন নিয়মে কোনো ভুল পাওয়া যায়নি।"))
    }

    private fun requestMic() {
        val lang = if (sourceIndex == 0) null else PolyLanguage.entries[sourceIndex - 1]
        if (lang == null || !lang.supportsSpeech) {
            status(tr("Select English or Arabic as source to record speech.", "কথা বলার জন্য ইংরেজি অথবা আরবি নির্বাচন করুন।"))
            return
        }
        pendingMicLanguage = lang
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micPermissionRequest)
        } else startMic(lang)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micPermissionRequest) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) pendingMicLanguage?.let { startMic(it) }
            else status(tr("Microphone permission denied.", "মাইক্রোফোনের অনুমতি দেওয়া হয়নি।"))
        }
    }

    private fun startMic(lang: PolyLanguage) {
        status(tr("Listening offline (${lang.englishName})…", "অফলাইনে শুনছে (${lang.nativeName})…"))
        voice.start(lang, result = { recognized ->
            inputField.setText(recognized)
            inputField.setSelection(recognized.length)
            status(tr("Speech captured. Translating…", "কথা লেখা হয়েছে। অনুবাদ হচ্ছে…"))
            translate()
        }, error = { message -> status(message) })
    }

    private fun speakOriginal() {
        val original = inputField.text.toString().trim()
        if (original.isEmpty()) return
        val lang = if (sourceIndex == 0) lastDetected else PolyLanguage.entries[sourceIndex - 1]
        if (lang == null || !lang.supportsSpeech) {
            status(tr("Select English or Arabic as source to hear it.", "মূল লেখা শুনতে ইংরেজি অথবা আরবি নির্বাচন করুন।"))
            return
        }
        speaker.speak(original, lang) { error ->
            status(error ?: tr("Playing source pronunciation.", "মূল লেখার উচ্চারণ চলছে।"))
        }
    }

    private fun speakTranslation() {
        if (lastOutput.isBlank()) { status(tr("Translate some text first.", "প্রথমে অনুবাদ করুন।")); return }
        val lang = PolyLanguage.entries[targetIndex]
        speaker.speak(lastOutput, lang) { error ->
            if (error != null) status(error)
            else status(tr("Playing offline ${lang.englishName} pronunciation.", "অফলাইনে ${lang.nativeName} উচ্চারণ চলছে।"))
        }
    }

    private fun copyTranslation() {
        if (lastOutput.isBlank()) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("PolyLingo translation", lastOutput))
        toast(tr("Copied", "কপি হয়েছে"))
    }

    private fun pasteClipboard() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = clipboard.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!text.isNullOrBlank()) inputField.setText(text)
    }

    private fun shareTranslation() {
        if (lastOutput.isBlank()) return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, lastOutput)
        }
        startActivity(Intent.createChooser(send, tr("Share translation", "অনুবাদ শেয়ার করুন")))
    }

    private fun toggleFavorite() {
        val id = currentRecordId
        if (id == null) { status(tr("Translate text before saving.", "সেভ করার আগে অনুবাদ করুন।")); return }
        currentFavorite = !currentFavorite
        history.setFavorite(id, currentFavorite)
        favoriteButton.text = if (currentFavorite) "★" else "☆"
        renderHistory()
    }

    private fun renderHistory() {
        if (!::historyList.isInitialized) return
        historyList.removeAllViews()
        val items = history.list(favoritesOnly)
        if (items.isEmpty()) {
            historyList.addView(text(tr("Nothing saved yet.", "এখনও কোনো অনুবাদ নেই।"), 13f, muted = true))
            return
        }
        for (item in items) {
            val entry = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(11), dp(12), dp(11))
                background = rounded(colors.background, 12)
                isClickable = true
                setOnClickListener { loadHistory(item) }
            }
            entry.addView(text("${if (item.favorite) "★ " else ""}${item.source.nativeName}  →  ${item.target.nativeName}", 12f, true).apply {
                setTextColor(colors.accent)
            })
            entry.addView(gap(4))
            entry.addView(text(item.original.replace('\n', ' ').take(95), 13f).apply { maxLines = 2 })
            entry.addView(text(item.translated.replace('\n', ' ').take(95), 12f, muted = true).apply { maxLines = 2 })
            historyList.addView(entry, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                bottomMargin = dp(8)
            })
        }
    }

    private fun loadHistory(item: HistoryItem) {
        sourceIndex = item.source.ordinal + 1
        targetIndex = item.target.ordinal
        lastInput = item.original
        lastOutput = item.translated
        currentRecordId = item.id
        currentFavorite = item.favorite
        render()
        refreshModels()
        status(tr("Loaded from history.", "ইতিহাস থেকে নেওয়া হয়েছে।"))
        scroll.smoothScrollTo(0, 0)
    }

    private fun swapLanguages() {
        val source = if (sourceIndex == 0) lastDetected else PolyLanguage.entries[sourceIndex - 1]
        val target = PolyLanguage.entries[targetIndex]
        sourceIndex = target.ordinal + 1
        targetIndex = (source ?: PolyLanguage.EN).ordinal
        if (lastOutput.isNotBlank()) {
            val previous = lastInput
            lastInput = lastOutput
            lastOutput = previous
            currentRecordId = null
            currentFavorite = false
        }
        render()
        refreshModels()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        voice.release()
        speaker.release()
        detector.close()
        history.close()
        super.onDestroy()
    }
}
