package com.polylingo.ai.core

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateRemoteModel

class OfflineModels {
    private val manager = RemoteModelManager.getInstance()

    fun installed(callback: (Set<String>) -> Unit) {
        manager.getDownloadedModels(TranslateRemoteModel::class.java)
            .addOnSuccessListener { models -> callback(models.map { it.language }.toSet()) }
            .addOnFailureListener { callback(emptySet()) }
    }

    /** Downloads only after an explicit user action. Progress is one language pack at a time. */
    fun downloadAll(
        progress: (completed: Int, total: Int, language: PolyLanguage, error: String?) -> Unit,
        finished: () -> Unit
    ) {
        val languages = PolyLanguage.entries.toList()
        fun next(index: Int) {
            if (index == languages.size) {
                finished()
                return
            }
            val lang = languages[index]
            val model = TranslateRemoteModel.Builder(lang.code).build()
            manager.download(model, DownloadConditions.Builder().build())
                .addOnSuccessListener {
                    progress(index + 1, languages.size, lang, null)
                    next(index + 1)
                }
                .addOnFailureListener { error ->
                    progress(index + 1, languages.size, lang, error.localizedMessage ?: "Download failed")
                    next(index + 1)
                }
        }
        next(0)
    }
}
