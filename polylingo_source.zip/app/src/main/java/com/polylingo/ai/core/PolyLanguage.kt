package com.polylingo.ai.core

enum class PolyLanguage(val code: String, val nativeName: String, val englishName: String) {
    BN("bn", "বাংলা", "Bengali"),
    EN("en", "English", "English"),
    AR("ar", "العربية", "Arabic"),
    HI("hi", "हिन्दी", "Hindi"),
    UR("ur", "اردو", "Urdu");

    val supportsSpeech: Boolean get() = this == EN || this == AR

    companion object {
        fun fromCode(code: String?): PolyLanguage? = entries.firstOrNull { it.code == code?.substringBefore('-') }
    }
}
