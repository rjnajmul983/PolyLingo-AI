package com.polylingo.ai.speech

import android.content.Context
import android.speech.tts.TextToSpeech
import com.polylingo.ai.core.PolyLanguage

/** Only picks voices which explicitly report they do NOT need a network. */
class OfflineSpeaker(context: Context) {
    private var ready = false
    private var tts: TextToSpeech? = null
    private var speed = 0.92f

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
        }
    }

    fun speak(text: String, language: PolyLanguage, callback: (String?) -> Unit) {
        if (!language.supportsSpeech) {
            callback("Only English and Arabic can be spoken.")
            return
        }
        val engine = tts
        if (!ready || engine == null) {
            callback("Speech engine is not ready. Try again shortly.")
            return
        }
        val offlineVoice = engine.voices?.firstOrNull {
            it.locale.language == language.code && !it.isNetworkConnectionRequired
        }
        if (offlineVoice == null) {
            callback("Offline ${language.englishName} voice not installed. Install it from Android Text-to-speech settings.")
            return
        }
        val setResult = engine.setVoice(offlineVoice)
        if (setResult == TextToSpeech.ERROR) {
            callback("Could not activate offline voice.")
            return
        }
        engine.setSpeechRate(speed)
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "poly-${System.nanoTime()}")
        callback(if (result == TextToSpeech.SUCCESS) null else "Could not speak text.")
    }

    fun setSpeed(value: Float) { speed = value.coerceIn(0.6f, 1.4f) }
    fun stop() = tts?.stop()
    fun release() { tts?.stop(); tts?.shutdown(); tts = null }
}
