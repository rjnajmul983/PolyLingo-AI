package com.polylingo.ai.core

import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions

/** Uses ML Kit's ON-DEVICE engine. Model download is a one-time setup requirement. */
class TranslationEngine {
    fun translate(text: String, source: PolyLanguage, target: PolyLanguage, done: (Result<String>) -> Unit) {
        if (source == target) {
            done(Result.success(text))
            return
        }
        val translator = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(source.code)
                .setTargetLanguage(target.code)
                .build()
        )
        translator.downloadModelIfNeeded()
            .addOnSuccessListener {
                translator.translate(text)
                    .addOnSuccessListener { result ->
                        translator.close()
                        done(Result.success(result))
                    }
                    .addOnFailureListener { error ->
                        translator.close()
                        done(Result.failure(error))
                    }
            }
            .addOnFailureListener { error ->
                translator.close()
                done(Result.failure(error))
            }
    }
}
