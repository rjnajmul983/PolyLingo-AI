package com.polylingo.ai.speech

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.polylingo.ai.core.PolyLanguage

/** Deliberately never falls back to a network recognizer. Android 12+ required. */
class OfflineVoice(private val activity: Activity) {
    private var recognizer: SpeechRecognizer? = null

    fun start(language: PolyLanguage, result: (String) -> Unit, error: (String) -> Unit) {
        if (!language.supportsSpeech) {
            error("Speech input is available for English and Arabic only.")
            return
        }
        if (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(activity)) {
            error("No Android on-device speech recognizer is installed. Install offline speech language packs in your phone settings.")
            return
        }
        release()
        recognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(activity)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onError(code: Int) { error("Offline speech recognition failed (code $code). Check that ${language.englishName} speech files are installed.") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (text.isNullOrBlank()) error("No speech recognized.") else result(text)
            }
            override fun onPartialResults(partialResults: Bundle?) = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.code)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) {
            error(e.localizedMessage ?: "Unable to start microphone")
            release()
        }
    }

    fun release() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
    }
}
