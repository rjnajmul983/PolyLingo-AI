package com.polylingo.ai.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CorrectionsTest {
    @Test fun englishTypoAndGrammar() {
        val result = Corrections.correct("I is sure teh answer is right", PolyLanguage.EN)
        assertEquals("I am sure the answer is right", result.text)
        assertTrue(result.changes >= 2)
    }

    @Test fun arabicSpelling() {
        assertEquals("إن شاء الله", Corrections.correct("انشاء الله", PolyLanguage.AR).text)
    }

    @Test fun languageCount() {
        assertEquals(5, PolyLanguage.entries.size)
        assertEquals(2, PolyLanguage.entries.count { it.supportsSpeech })
    }
}
